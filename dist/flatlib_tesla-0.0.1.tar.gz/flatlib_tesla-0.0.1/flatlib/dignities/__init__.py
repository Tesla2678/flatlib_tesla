"""
    This file is part of flatlib - (C) FlatAngle
    Author: João Ventura (flatangleweb@gmail.com)
    
    
    This subpackage implements the Essential and
    Accidental dignities.
  
"""