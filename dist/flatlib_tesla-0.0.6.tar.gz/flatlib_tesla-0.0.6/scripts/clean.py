"""
 Cleans the python cache folders in the application

"""

import utils


utils.clean_caches(utils.PKG_DIR)
