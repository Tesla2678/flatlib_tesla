## Recipes

This folder includes small scripts which are worth keeping.